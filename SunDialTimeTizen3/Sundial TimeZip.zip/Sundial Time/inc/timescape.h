#include "locations.h" //for gps
#include "math.h"
#include "time.h"
#include "Ecore.h"

#define PI 3.1415926535897932384

float var_azimuth;
float var_elevation;

void color_to_text();
char color_to_text_op[200];

//double sunRiseHours; //e.g. 5.5;
double hoursOfDaylight;
double sunSetHours; //time of sunset

int dayOfYear;
int dayOfMonth;
int monthOfYear;
int currentYear;
float currentMinute; //was float
int currentHour;

/*
double sunSetTime;
double sunRiseTime; //made into locals
*/


double rise;
double set;

double var_latitude;
double var_longitude;
double var_altitude;

//double risingTime;
//double rlong;
//double rlat;

//double pi = 3.1415926535; //8979;
double pi = 3.1415926535897932384626433832795;
char currentTime[100];

//int var_intervalGPS = 10; //gps every x seconds was 10

location_manager_h location_manager;

Ecore_Timer * bob_update_timer;

int got_gps; //for quarter day checker.

int timeFormat = 0; //12 hr/   1= 24 hr

char decimal_to_time_output[20];

void decimal_to_time(double hours) //eg 12.4213
{
	int newHours = floorf(hours); //8.2
	int newMinutes = (hours - floorf(hours)) * 60;
	//newMinutes
	char hourText[10];
	sprintf(hourText,"%d",newHours);

	char minuteText[10] = "";
	sprintf(minuteText,"%d",newMinutes); //was %2d

	char output[20] = "";
	strcat(output,hourText);
	strcat(output,":");
	if (newMinutes < 10)
	{
	strcat(output,"0");
	}
	strcat(output,minuteText);

	strcpy(decimal_to_time_output,output);

}

void get_time_str () {
 //  time_t curTime;
	time_t rawTime = time(NULL);

//	struct tm * localtime(const time_t *clock);
	struct tm *ptm = localtime(&rawTime);
   //time(&curtime);
  // localtime(&curTime);
   dayOfYear = ptm->tm_yday;
   dayOfMonth = ptm->tm_mday;
   monthOfYear = ptm->tm_mon + 1; //0 - 11

   currentYear = ptm->tm_year + 1900; // 119
   currentMinute = ptm->tm_min;
   currentHour = ptm->tm_hour;

   return;
}

int get_difference_time()
{
	int h1, h2;
		    time_t hour_machine;
		    struct tm *local_hour, *gmt_hour;

		    time( &hour_machine );      // Get time as long integer.
		   	    gmt_hour =  gmtime( &hour_machine );
		   	    h1 = gmt_hour->tm_hour;
		   	    local_hour = localtime( &hour_machine );    // local time.
		   	    h2 = local_hour->tm_hour;
		   	    //gmt time is 4 hours ahead of lincolnville
		   	    //2pm in greenwhich, 10am in lincolnville
		   	    int difference = (h2 - h1);

		   	    return difference;
}

void toggle_time_format()
{
	if (timeFormat == 0)
	{
		timeFormat = 1;

	} else if (timeFormat == 1)
	{
		timeFormat = 0;
	}
}

double calculate_sun(int toggle,double lat, double lng)
{
	get_time_str();

	//	double lat = 44.48779; //BANGOR ME FOR HUNTING
	//	double lng = -68.46779;
	//double lat = var_latitude;
	//double lng = var_longitude;
	//double lat = use_latitude;
	//double lng = use_longitude;
		double lngHour = lng / 15.0;
		double N = dayOfYear;

		double t;
		if (toggle == 0) {
		    t = N + ((6 - lngHour) / 24);
		}//if rising time is desired:
		else {
		    t = N + ((18 - lngHour) / 24);   //if setting time is desired:
		}
		    //3. calculate the Sun's mean anomaly
		    double M = (0.98560028 * t) - 3.289; //0028 added

		    //4. calculate the Sun's true longitude
		    double L = fmod(M + (1.916 * sin((PI/180)*M)) + (0.020 * sin(2 *(PI/180) * M)) + 282.634,360.0);

		    //5a. calculate the Sun's right ascension
		    double RA = fmod(180/PI*atan(0.91764 * tan((PI/180)*L)),360.0);

		    //5b. right ascension value needs to be in the same quadrant as L
		    double Lquadrant  = floorf( L/90) * 90;
		    double RAquadrant = floorf(RA/90) * 90;
		    RA = RA + (Lquadrant - RAquadrant);

		    //5c. right ascension value needs to be converted into hours
		    RA = RA / 15;

		    //6. calculate the Sun's declination
		    double sinDec = 0.39782 * sin((PI/180)*L);
		    double cosDec = cos(asin(sinDec));

		    //7a. calculate the Sun's local hour angle
		    double zenith = -0.83; //atmospheric refraction
		    //double zenith = -0.6;
		    double cosH = (sin((PI/180)*zenith) - (sinDec * sin((PI/180)*lat))) / (cosDec * cos((PI/180)*lat));
		    /*
		    if (cosH >  1)
		    the sun never rises on this location (on the specified date)
		    if (cosH < -1)
		    the sun never sets on this location (on the specified date)
		    */

		    //7b. finish calculating H and convert into hours
		    double H;
		    if (toggle == 0) {
		    H = 360 - (180/PI)*acos(cosH);
		    }//   if if rising time is desired:
		    else {
		    H = (180/PI)*acos(cosH);
		    }

		    //float H = acos(cosH) //   if setting time is desired:
		    H = H / 15;

		    //8. calculate local mean time of rising/setting
		    double T = H + RA - (0.06571 * t) - 6.622;

	//		if (T < 0) { T = T + 24; }
	//		if (T > 24) { T = T - 24; }
	//		if (T > 12) { T = T - 12; }

		    //9. adjust back to UTC

		    double UT = fmod(T - lngHour,24.0);

		    int difference = get_difference_time();
		    double final = UT + difference;
		    if (final < 0) { final = final + 24; }
		    if (final >= 24){ final = final - 24; }

		    return final;
}

/*

[in]	manager	The location manager handle
[out]	altitude	The current altitude (meters)
[out]	latitude	The current latitude [-90.0 ~ 90.0] (degrees)
[out]	longitude	The current longitude [-180.0 ~ 180.0] (degrees)
[out]	climb	The climb (km/h)
[out]	direction	The direction, degrees from the north
[out]	speed	The speed (km/h)
[out]	level	The accuracy level
[out]	horizontal	The horizontal accuracy (meters)
[out]	vertical	The vertical accuracy (meters)
[out]	timestamp	The timestamp (time when measurement took place or 0 if valid)

 */

void position_updated_cb(double latitude, double longitude, double altitude, time_t timestamp, void *user_data)
{
	//int trash;
	//double altitude;
//	float latitude;
//	float longitude;
	double climb;
	double direction;
	double speed;   //km/h  	//USE THIS FOR TIME DILATION
	double horizontal;
	double vertical;
	//double speed;
	//double timestamp;
	location_accuracy_level_e level;
	//location_manager_get_last_location();
	//get values but didnt update climb
	location_manager_get_last_location(location_manager, &altitude, &latitude, &longitude,
	                                         &climb, &direction, &speed, &level, &horizontal,
	                                         &vertical, &timestamp);


	var_latitude = latitude;
	var_longitude = longitude;
	var_altitude = altitude;

//	var_latitude = 44.48779; //BANGOR ME FOR HUNTING
//	var_longitude = -68.46779;

	rise = calculate_sun(0,var_latitude,var_longitude);
	set = calculate_sun(1,var_latitude,var_longitude);

	got_gps = 1;


}

void gps_satellite_callback(float azimuth, float elevation, time_t timestamp,void *user_data)
{

	var_azimuth = azimuth;
	var_elevation = elevation;

}

void load_location(int interval) //LOAD GPS
{
    // Creating location manager for Global Positioning System
    // The LOCATIONS_METHOD_GPS setting means that this location manager will use
    // only GPS satellites to check the device's location.

	if(location_manager_create(LOCATIONS_METHOD_GPS, &location_manager) == LOCATIONS_ERROR_NONE)
    {
        //LOGI("Location manager created.");
        // Setting callback for position update - update will be done every x seconds.
        if (location_manager_set_position_updated_cb(location_manager, position_updated_cb, interval, NULL) == LOCATIONS_ERROR_NONE)
        {
            //LOGI("Location position update callback added.");
        }
        // Starting service
        if(location_manager_start(location_manager)== LOCATIONS_ERROR_NONE)
        {
            //LOGI("Location service started.");
        }
    }
 //doesnt work? maybe works but not supported?
//   gps_status_set_satellite_updated_cb(location_manager, gps_satellite_callback, 15 , NULL);
}

char color_to_text_op[200];

void color_to_text(char * color,char * text)
{
	char op[200] = "<color=#";
	strcat(op,color);
	strcat(op,">");
	strcat(op,text);
	strcat(op,"</color>");
	strcpy(color_to_text_op,op);
}

char fontsize_to_text_op[200];

void fontsize_to_text(int fontSize, char * text)
{
	char fontSizeStr[10];
	sprintf(fontSizeStr,"%d",fontSize);

	char op[200] = "<font_size=";
	strcat(op,fontSizeStr);
	strcat(op,">");
	strcat(op,text);
	strcat(op,"</font_size>");

	strcpy(fontsize_to_text_op,op);
}
