#include "app_main.h"
#include "uib_app_manager.h"
#include "locations.h"
#include "Ecore.h"


location_manager_h location_manager;

location_manager_h primary_location;

void position_updated_cb(); //both from view 1
double calculate_sun(); //from view1

void load_location();
double var_latitude = 0;
double var_longitude = 0;

double rise = 0;
double set = 0;

int oneDay = 24 * 60 * 60; //seconds in a day

int var_gps_on = 0; //0 or 1

Ecore_Timer * main_timer;

Ecore_Timer* recalc_rise_set;

int got_gps = 0; //for quarter day checker

/* app event callbacks */
static widget_class_h widget_app_create(void *user_data);
static void widget_app_terminate(void *user_data);
static int _on_create_cb(widget_context_h context, bundle *content, int w, int h, void *user_data);
static int _on_destroy_cb(widget_context_h context, widget_app_destroy_type_e reason, bundle *content, void *user_data);
static int _on_resume_cb(widget_context_h context, void *user_data);
static int _on_pause_cb(widget_context_h context, void *user_data);
static int _on_update_cb(widget_context_h context, bundle *content, int force, void *user_data);
static int _on_update_resize(widget_context_h context, int w, int h, void *user_data);
static void _on_low_memory_cb(app_event_info_h event_info, void *user_data);
static void _on_low_battery_cb(app_event_info_h event_info, void *user_data);
static void _on_device_orientation_cb(app_event_info_h event_info,
		void *user_data);
static void _on_language_changed_cb(app_event_info_h event_info,
		void *user_data);
static void _on_region_format_changed_cb(app_event_info_h event_info,
		void *user_data);

void nf_hw_back_cb(void* param, Evas_Object * evas_obj, void* event_info) {
	//TODO : user define code
	evas_obj = uib_views_get_instance()->get_window_obj()->app_naviframe;
	elm_naviframe_item_pop(evas_obj);
}

void win_del_request_cb(void *data, Evas_Object *obj, void *event_info) {
	ui_app_exit();
}

Eina_Bool nf_root_it_pop_cb(void* elm_win, Elm_Object_Item *it) {
	elm_win_lower(elm_win);
	return EINA_FALSE;
}

app_data *uib_app_create() {
	return calloc(1, sizeof(app_data));
}

void uib_app_destroy(app_data *user_data) {
	uib_app_manager_get_instance()->free_all_view_context();
	free(user_data);
}

int uib_app_run(app_data *user_data, int argc, char **argv) {
	widget_app_lifecycle_callback_s cbs = { 0, };

	cbs.create = widget_app_create;
	cbs.terminate = widget_app_terminate;

	int ret = widget_app_main(argc, argv, &cbs, user_data);
	if (ret != WIDGET_ERROR_NONE) {
		UIB_DLOG(DLOG_ERROR, LOG_TAG, "widget_app_main() is failed. err = %d",
				ret);
	}

	return ret;
}

static widget_class_h widget_app_create(void *user_data) {
	app_event_handler_h handlers[5] = { NULL, };

	widget_app_add_event_handler(&handlers[APP_EVENT_LOW_BATTERY],
			APP_EVENT_LOW_BATTERY, _on_low_battery_cb, user_data);
	widget_app_add_event_handler(&handlers[APP_EVENT_LOW_MEMORY],
			APP_EVENT_LOW_MEMORY, _on_low_memory_cb, user_data);
	widget_app_add_event_handler(
			&handlers[APP_EVENT_DEVICE_ORIENTATION_CHANGED],
			APP_EVENT_DEVICE_ORIENTATION_CHANGED, _on_device_orientation_cb,
			user_data);
	widget_app_add_event_handler(&handlers[APP_EVENT_LANGUAGE_CHANGED],
			APP_EVENT_LANGUAGE_CHANGED, _on_language_changed_cb, user_data);
	widget_app_add_event_handler(&handlers[APP_EVENT_REGION_FORMAT_CHANGED],
			APP_EVENT_REGION_FORMAT_CHANGED, _on_region_format_changed_cb,
			user_data);

	widget_instance_lifecycle_callback_s cbs = {
			.create = _on_create_cb,
			.destroy = _on_destroy_cb,
			.pause = _on_pause_cb,
			.resume = _on_resume_cb,
			.update = _on_update_cb,
			.resize = _on_update_resize,
	};

	return widget_app_class_create(cbs, user_data);
}

static
void widget_app_terminate(void *user_data) {
	uib_views_get_instance()->destroy_window_obj();
}


Eina_Bool change_loc_interval_cb() //get a position, then switch to 120
{	//get a position then switch to 120 seconds. 'gps high'
	int maximum = 120;

	if (got_gps == 0) {
		return ECORE_CALLBACK_RENEW;
	} else {
		location_manager_stop(location_manager);
		location_manager_set_position_updated_cb(location_manager, position_updated_cb, maximum, NULL);
		location_manager_start(location_manager);
		return ECORE_CALLBACK_CANCEL;
	}
}


Eina_Bool gps_off_when_have_pos(location_manager_h *manager) //to turn off gps after got gps pos.
{
	//get a gps position, then stop manager and cancel cb.


	if (got_gps == 0) //while i havent got gps, renew
	{
		return ECORE_CALLBACK_RENEW;
	} else //have got a new gps reading

	{	//have gps position, turn it off
		location_manager_stop(*manager); //stop location

		//done
		return ECORE_CALLBACK_CANCEL;
	}

}



Eina_Bool gps_get_position_low_rate_cb() //called 4x a day, resets lat and long
{
	//gets a gps position ~once. uses an independant location manager.


	//if gps 'on' button pressed, already checking.
	if (var_gps_on == 1) {return ECORE_CALLBACK_RENEW; }

	//reset variable
	got_gps = 0; //turns 1 when i have a reading

	//set to get new position every ten seconds.
	location_manager_stop(primary_location);
	location_manager_set_position_updated_cb(primary_location, position_updated_cb, 10, NULL);
	location_manager_start(primary_location);
	// to turn off after got gps pos.
	ecore_timer_add(10,gps_off_when_have_pos,&primary_location);

	return ECORE_CALLBACK_RENEW;
}

void start_main_gps_timer() //quarter day gps timer set
{
	//start checking every quarter day
	recalc_rise_set = ecore_timer_add(oneDay/4,gps_get_position_low_rate_cb, NULL);

}

void load_location_primary(int interval) //LOAD GPS
{
    // Creating location manager for Global Positioning System
    // The LOCATIONS_METHOD_GPS setting means that this location manager will use
    // only GPS satellites to check the device's location.

	if(location_manager_create(LOCATIONS_METHOD_GPS, &primary_location) == LOCATIONS_ERROR_NONE)
    {
        //LOGI("Location manager created.");
        // Setting callback for position update - update will be done every x seconds.
        if (location_manager_set_position_updated_cb(primary_location, position_updated_cb, interval, NULL) == LOCATIONS_ERROR_NONE)
        {
            //LOGI("Location position update callback added.");
        }
        // Starting service
        if(location_manager_start(primary_location)== LOCATIONS_ERROR_NONE)
        {
            //LOGI("Location service started.");
        }
    }
 //doesnt work? maybe works but not supported?
//   gps_status_set_satellite_updated_cb(location_manager, gps_satellite_callback, 15 , NULL);
}

static int _on_create_cb(widget_context_h context, bundle *content, int w, int h, void *user_data) {


	uib_app_manager_get_instance()->initialize(context, w, h);

//RUSS ADDED

	load_location(10); //loads location manager for gps view.
	load_location_primary(10); //primary_location for quarter day checks.

	//get a location then stop gps.
	got_gps = 0; //sanity... this is redundant.
	main_timer = ecore_timer_add(10,gps_off_when_have_pos,&location_manager);

	//turn on GPS temporarily every 6 hours//
	start_main_gps_timer();
//END RUSS ADDED
	return WIDGET_ERROR_NONE;
}

static int _on_destroy_cb(widget_context_h context, widget_app_destroy_type_e reason, bundle *content, void *user_data) {
	return WIDGET_ERROR_NONE;
}

static int _on_resume_cb(widget_context_h context, void *user_data) {
	/* Take necessary actions when widget instance becomes visible. */
	return WIDGET_ERROR_NONE;
}

static int _on_pause_cb(widget_context_h context, void *user_data) {
	/* Take necessary actions when widget instance becomes invisible. */
	return WIDGET_ERROR_NONE;
}

static int _on_update_cb(widget_context_h context, bundle *content, int force,
		void *user_data) {
	/* Take necessary actions when widget instance should be updated. */
	return WIDGET_ERROR_NONE;
}

static int _on_update_resize(widget_context_h context, int w, int h,
		void *user_data) {
	/* Take necessary actions when the size of widget instance was changed. */
	return WIDGET_ERROR_NONE;
}

static void _on_low_battery_cb(app_event_info_h event_info, void *user_data) {
	/* Take necessary actions when the battery is low. */
}

static void _on_low_memory_cb(app_event_info_h event_info, void *user_data) {
	/* Take necessary actions when the system runs low on memory. */
}

static void _on_device_orientation_cb(app_event_info_h event_info,
		void *user_data) {
	/* deprecated APIs */
}

static void _on_language_changed_cb(app_event_info_h event_info,
		void *user_data) {
	/* Take necessary actions is called when language setting changes. */
	uib_views_get_instance()->uib_views_current_view_redraw();
}

static void _on_region_format_changed_cb(app_event_info_h event_info,
		void *user_data) {
	/* Take necessary actions when region format setting changes. */
}

